
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './style.css';
import './style1.css';
import './style2.css';
import './style3.css';

function App() {
  return (
    <Router>
      <header className="header">
        <div className="logo">
          <Link to="/">Poligedon</Link>
        </div>
        <nav>
          <ul>
            <li><Link to="/">Strona Główna</Link></li>
            <li><Link to="/galeria">Galeria</Link></li>
            <li><Link to="/contact">Kontakt</Link></li>
            <li><Link to="/regulamin">Regulamin</Link></li>
          </ul>
        </nav>
      </header>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/galeria" element={<Galeria />} />
        <Route path="/contact" element={<Kontakt />} />
        <Route path="/regulamin" element={<Regulamin />} />
      </Routes>

      <footer>
        <p>&copy; 2025 Poligedon. Wszelkie prawa zastrzeżone.</p>
      </footer>
    </Router>
  );
}

function Home() {
  return (
    <main className="container">
      <section className="hero">
        <div className="hero-content">
          <h1>10–11 maja 2025</h1>
          <h2>Zapisz się już dziś!</h2>
          <p>Dołącz do biegu Poligedon o puchar JM Rektora!</p>
          <button className="btn">Zapisz się teraz</button>
        </div>
      </section>
      <section>
        <h2>Witaj na stronie Poligedon!</h2>
        <p>Ta strona została przeniesiona do React.</p>
      </section>
    </main>
  );
}

function Galeria() {
  return (
    <main className="container">
      <h2>Galeria</h2>
      <p>Galeria zdjęć z wydarzenia. Zdjęcia można umieścić w folderze public/images i odwołać je przez src="/images/zdj.jpg".</p>
      <div className="gallery">
        <img src="/images/zdj1.jpg" alt="Zdjęcie 1" />
        <img src="/images/z2.jfif" alt="Zdjęcie 2" />
        <img src="/images/z3.jpg" alt="Zdjęcie 3" />
      </div>
    </main>
  );
}

function Kontakt() {
  return (
    <main className="container">
      <h2>Kontakt</h2>
      <p>Skontaktuj się z nami:</p>
      <ul>
        <li>Email: kontakt@poligedon.pl</li>
        <li>Telefon: +48 123 456 789</li>
        <li>Adres: ul. Żeromskiego 116, Łódź</li>
      </ul>
    </main>
  );
}

function Regulamin() {
  return (
    <main className="container">
      <h2>Regulamin</h2>
      <p>Pełna treść regulaminu:</p>
      <div style={{ backgroundColor: '#fff', padding: '1rem', borderRadius: '8px' }}>
        <p>1. Każdy uczestnik bierze udział na własną odpowiedzialność.</p>
        <p>2. Organizatorzy nie ponoszą odpowiedzialności za ewentualne urazy.</p>
        <p>3. Wydarzenie odbywa się w dniach 10–11 maja 2025 roku.</p>
        <p>4. Więcej szczegółów będzie dostępnych w regulaminie PDF.</p>
      </div>
    </main>
  );
}

export default App;
