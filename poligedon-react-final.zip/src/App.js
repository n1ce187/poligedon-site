
import React from 'react';
import './style.css';
import './style1.css';
import './style2.css';
import './style3.css';

function App() {
  return (
    <div>
      <header className="logo">Poligedon</header>
      <main>
        <section className="hero">
          <div className="hero-content">
            <h1>10–11 maja 2025</h1>
            <h2>Zapisz się już dziś!</h2>
            <p>Dołącz do biegu Poligedon o puchar JM Rektora!</p>
            <button className="btn">Zapisz się teraz</button>
          </div>
        </section>
        <section className="container">
          <h2>Witaj na stronie Poligedon!</h2>
          <p>Ta strona została przeniesiona do React.</p>
        </section>
      </main>
      <footer>
        <p>&copy; 2025 Poligedon. Wszelkie prawa zastrzeżone.</p>
      </footer>
    </div>
  );
}

export default App;
